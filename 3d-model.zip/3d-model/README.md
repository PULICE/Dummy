### 3d models
- File name is included 'metal' which means it is a CNC part
- You have to take your own risk to practice these models
- Send your feedback is always welcome!
- J6末端对精度要求不高，正在考虑用个成本更低的28行星减速器，

- 231208FAN
- 添加stp文件和dxf文件其他文件仅供参考
- 文件都在压缩包中OutStpFan.zip Excel文档最后一个page添加cnc加工BOM
